abstract class AppStates{}
class AppInitialState extends AppStates{}
class createDB extends AppStates{}
class insertintoDB extends AppStates{}
class getFromDB extends AppStates{}
class search extends AppStates{}
class UBdateDB extends AppStates{}